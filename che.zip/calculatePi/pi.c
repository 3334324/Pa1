#include<stdio.h>

/* Pseudocode:
BEGIN
	integer countTotal = 0
	integer countInside = 0
	WHILE countTotal < A large number
		x = random number between 0 and 1
		y = random number between 0 and 1
		countTotal = countTotal + 1
		IF x*x + y*y < 1
			countInside = countInside + 1
		ENDIF
	ENDWHILE
	pi = 4*countInside/countTotal
	PRINT pi
END
*/

int main()
{
   // This is blank for now, we will fill it in during the lecture
   return 0;
}
