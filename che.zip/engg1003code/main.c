#include <stdio.h>

int main() {
	printf("Woo! You got the template working!\n");
	return 0;
}
