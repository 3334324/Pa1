# engg1003code
Basic template for ENGG1003 students to load in Che

This template should work with the default Che "make" based build script or my custom "gcc -Wall -g -O0 *.c -lm" one
